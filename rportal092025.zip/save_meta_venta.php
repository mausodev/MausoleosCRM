<?php
require './controlador/conexion.php';

// Disable error reporting to prevent PHP errors from breaking JSON output
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data received');
    }

    if (!isset($data['id']) || !isset($data['puesto']) || !isset($data['metas'])) {
        throw new Exception('Missing required parameters');
    }

    // Get logged in user's email and plaza from session
    session_start();
    $usuario_logueado = $_SESSION['correo'] ?? null;
    $plaza_usuario = $_SESSION['sucursal'] ?? null;

    if (!$usuario_logueado || !$plaza_usuario) {
        throw new Exception('No se encontró la información del usuario logueado');
    }

    $id = $data['id'];
    $puesto = $data['puesto'];
    $metas = $data['metas'];

    // Assign the correct ID field based on the role
    $id_field = ($puesto === 'ASESOR') ? 'id_asesor' : 'id_cordinador';
    $id_value = $id;

    $con->begin_transaction();

    foreach ($metas as $meta) {
        // Check if record exists
        $check_query = "SELECT id FROM meta_venta WHERE mes = ? AND $id_field = ?";
        $check_stmt = $con->prepare($check_query);
        if (!$check_stmt) {
            throw new Exception('Database prepare error: ' . $con->error);
        }

        $check_stmt->bind_param("ii", $meta['mes'], $id_value);
        if (!$check_stmt->execute()) {
            throw new Exception('Database execute error: ' . $check_stmt->error);
        }

        $result = $check_stmt->get_result();
        if (!$result) {
            throw new Exception('Database result error: ' . $check_stmt->error);
        }
        
        if ($result->num_rows > 0) {
            // Update existing record
            $update_query = "UPDATE meta_venta SET meta = ?, campo = ?, plaza = ? WHERE mes = ? AND $id_field = ?";
            $update_stmt = $con->prepare($update_query);
            if (!$update_stmt) {
                throw new Exception('Database prepare error: ' . $con->error);
            }

            $update_stmt->bind_param("dssii", 
                $meta['meta'], 
                $usuario_logueado,
                $plaza_usuario,
                $meta['mes'], 
                $id_value
            );
            if (!$update_stmt->execute()) {
                throw new Exception('Database execute error: ' . $update_stmt->error);
            }
        } else {
            // Insert new record
            $insert_query = "INSERT INTO meta_venta (mes, meta, nombre_mes, $id_field, campo, plaza) VALUES (?, ?, ?, ?, ?, ?)";
            $insert_stmt = $con->prepare($insert_query);
            if (!$insert_stmt) {
                throw new Exception('Database prepare error: ' . $con->error);
            }

            $insert_stmt->bind_param("idsiss", 
                $meta['mes'], 
                $meta['meta'], 
                $meta['nombre_mes'], 
                $id_value,
                $usuario_logueado,
                $plaza_usuario
            );
            if (!$insert_stmt->execute()) {
                throw new Exception('Database execute error: ' . $insert_stmt->error);
            }
        }
    }
    
    $con->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    if (isset($con) && $con->inTransaction()) {
        $con->rollback();
    }
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?> 