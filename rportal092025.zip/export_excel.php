<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=bono_proyeccion.xls");

include("get_data.php");
?>

<table>
    <tr>
        <th>Coordinador</th>
    </tr>
</table>
