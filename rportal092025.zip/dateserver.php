<?php
echo "Hora del servidor: " . date("Y-m-d H:i:s");
echo "<br>Zona horaria: " . date_default_timezone_get();
?>
